package ro.star.elearning.entities;

public class User {
	
	public static String userName="user";
	
	public static String password="1";

}