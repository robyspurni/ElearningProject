package ro.star.elearning.entities;

import java.io.Serializable;
import java.util.ArrayList;

public class Account implements Serializable{
	protected int ID;
	protected String Username;
	protected String FirstName;
	protected String LastName;
	protected String Email;
	protected String Role;
	protected String RegisteredDate;
	
	public Account(int iD, String username, String firstName, String lastName, String email, String role, String registeredDate) {
		
		ID = iD;
		Username = username;
		FirstName = firstName;
		LastName = lastName;
		Email = email;
		Role = role;
		RegisteredDate = registeredDate;
	}
	
	public static ArrayList<Account> getDefaultData(){
		ArrayList<Account> listWithAccounts = new ArrayList<Account>();
        
        listWithAccounts.add(new Account(1,"user1","Popa","Ion", "ion@gmail.com","role_user","07-07-2016"));
        listWithAccounts.add(new Account(2,"user2","Popescu","Ion", "ionP@gmail.com","role_user","17-06-2016"));
        listWithAccounts.add(new Account(3,"user3","Petrescu","Andreea", "andreea@gmail.com","role_user","03-07-2016"));
        listWithAccounts.add(new Account(4,"user4","Coteanu","Augustin", "augustin@gmail.com","role_teacher","01-06-2016"));
        listWithAccounts.add(new Account(5,"user5","Marius","Andrei", "marius@gmail.com","role_user","08-07-2016"));
        listWithAccounts.add(new Account(6,"user6","Spurni","Roberta", "roberta@gmail.com","role_user","08-07-2016"));
        listWithAccounts.add(new Account(7,"user7","Stochitoiu","Catalina", "catalina@gmail.com","role_user","08-07-2016"));
        listWithAccounts.add(new Account(8,"user8","Cirstea","Aurel", "aurel@gmail.com","role_user","09-07-2016"));
        listWithAccounts.add(new Account(9,"user9","Pana","ionut", "ionut@gmail.com","role_user","06-07-2016"));
        listWithAccounts.add(new Account(10,"user10","Netoiu","Adi", "adi@gmail.com","role_teacher","01-07-2016"));
        listWithAccounts.add(new Account(11,"admin","Admin","Admin", "admin@gmail.com","role_admin","01-01-2016"));
        
        return listWithAccounts;
	}

	public int getID() {
		return ID;
	}

	public void setID(int iD) {
		ID = iD;
	}

	public String getUsername() {
		return Username;
	}

	public void setUsername(String username) {
		Username = username;
	}

	public String getFirstName() {
		return FirstName;
	}

	public void setFirstName(String firstName) {
		FirstName = firstName;
	}

	public String getLastName() {
		return LastName;
	}

	public void setLastName(String lastName) {
		LastName = lastName;
	}

	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}

	public String getRole() {
		return Role;
	}

	public void setRole(String role) {
		Role = role;
	}

	public String getRegisteredDate() {
		return RegisteredDate;
	}

	public void setRegisteredDate(String registeredDate) {
		RegisteredDate = registeredDate;
	}
	
	
	
	
}
