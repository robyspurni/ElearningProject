package ro.star.internship.services;

import java.util.ArrayList;
import java.util.List;

import ro.star.internship.services.impl.LocationNodeImpl;

public class TreeDataFactory {
	public static LocationNodeImpl getSingleRoot() {
        LocationNodeImpl[] ACCourses = {
                new LocationNodeImpl("J2EE",   "course",     1),
                new LocationNodeImpl("Spring",     "course",     1),
                new LocationNodeImpl("Hibernate",    "course",     1)
        };

        LocationNodeImpl[] ANCourses = {
                new LocationNodeImpl(".Net",    "course",     1)
        };

        LocationNodeImpl[] MSCourses = {
                new LocationNodeImpl("iOS",      "course",     1),
                new LocationNodeImpl("Android",   "course",     1)
        };


        LocationNodeImpl[] teachers = {
                new LocationNodeImpl("Augustin Coteanu",    "teacher",    1, ACCourses),
                new LocationNodeImpl("Adi Netoiu",          "teacher",    1, ANCourses),
                new LocationNodeImpl("Marius Stancalie",    "teacher",    1, MSCourses),
                
        };

        return new LocationNodeImpl("List", "null" , 1, teachers);
    }

    public static List<LocationNodeImpl> getTreeRoots() {
        return new ArrayList<LocationNodeImpl>() {
		{
            add(getSingleRoot());
        }};
    }
}
