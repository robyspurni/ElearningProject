package ro.star.internship.beans;

import java.io.Serializable;
import java.util.Date;

import javax.faces.bean.CustomScoped;
import javax.faces.bean.ManagedBean;

import org.icefaces.ace.component.menuitem.MenuItem;
import org.icefaces.ace.component.submenu.Submenu;
import org.icefaces.ace.model.DefaultMenuModel;

@ManagedBean(name= DashboardBean.BEAN_NAME)
@CustomScoped(value = "#{window}")
public class DashboardBean implements Serializable {
    public static final String BEAN_NAME = "dashboardBean";
    public String getBeanName() { return BEAN_NAME; }
    private Date selectedDate = new Date(System.currentTimeMillis());
    private String locale;
    
    public DefaultMenuModel model;
    
    public String showAllTeachers(){
    	return "/teachers.xhtml?faces-redirect=true";
    }
	
    public String showAllCourses(){
    	return "/courses.xhtml?faces-redirect=true";
    }
    
    
    public DefaultMenuModel getModel() {
		model = new DefaultMenuModel();
		
	 	Submenu submenu = new Submenu();
	 	submenu.setId("Menu");
	 	submenu.setLabel("Menu");
	 	model.addSubmenu(submenu);
	 	
	  	MenuItem menuItem1 = new MenuItem();
	 	menuItem1.setId("DashBoard");
	 	menuItem1.setValue("DashBoard");
	 	menuItem1.setUrl("dashboard.xhtml");
	 	menuItem1.setIcon("ui-icon-home");
	 	submenu.getChildren().add(menuItem1);
	 	
	 	MenuItem menuItem2 = new MenuItem();
	 	menuItem2.setId("Email");
	 	menuItem2.setValue("Email");
	 	menuItem2.setUrl("email.xhtml");
	 	menuItem2.setIcon("ui-icon-mail-closed");
	 	submenu.getChildren().add(menuItem2);

	 	MenuItem menuItem3 = new MenuItem();
	 	menuItem3.setId("Chat");
	 	menuItem3.setValue("Chat");
	 	menuItem3.setUrl("chat.xhtml");
	 	menuItem3.setIcon("ui-icon-comment");
	 	submenu.getChildren().add(menuItem3);
	 	
	 	MenuItem menuItem4 = new MenuItem();
	 	menuItem4.setId("Groups");
	 	menuItem4.setValue("Groups");
	 	menuItem4.setUrl("groups.xhtml");
	 	menuItem4.setIcon("ui-icon-person");
	 	submenu.getChildren().add(menuItem4);
	 	
	 	MenuItem menuItem5 = new MenuItem();
	 	menuItem5.setId("Teachers");
	 	menuItem5.setValue("Teachers");
	 	menuItem5.setUrl("teachers.xhtml");
	 	menuItem5.setIcon("ui-icon-person");
	 	submenu.getChildren().add(menuItem5);
	 	
	 	MenuItem menuItem6 = new MenuItem();
	 	menuItem6.setId("Courses");
	 	menuItem6.setValue("Courses");
	 	menuItem6.setUrl("courses.xhtml");
	 	menuItem6.setIcon("/resources/chat.png");
	 	menuItem6.getIcon();
	 	submenu.getChildren().add(menuItem6);
	 	
	 	MenuItem menuItem7 = new MenuItem();
	 	menuItem7.setId("Accounts");
	 	menuItem7.setValue("Accounts");
	 	menuItem7.setUrl("accounts.xhtml");
	 	menuItem7.setIcon("/resources/chat.png");
	 	menuItem7.getIcon();
	 	submenu.getChildren().add(menuItem7);
	 	
	 	MenuItem menuItem8 = new MenuItem();
	 	menuItem8.setId("Events");
	 	menuItem8.setValue("Events");
	 	menuItem8.setUrl("events.xhtml");
	 	menuItem8.setIcon("/resources/chat.png");
	 	menuItem8.getIcon();
	 	submenu.getChildren().add(menuItem8);
	 	
	 	MenuItem menuItem9 = new MenuItem();
	 	menuItem9.setId("Notifications");
	 	menuItem9.setValue("Notifications");
	 	menuItem9.setUrl("notifications.xhtml");
	 	menuItem9.setIcon("/resources/chat.png");
	 	menuItem9.getIcon();
	 	submenu.getChildren().add(menuItem9);
	 	
	 	return model;
	}
	
    public Date getSelectedDate() {
        return selectedDate;
    }

    public void setSelectedDate(Date selectedDate) {
        this.selectedDate = selectedDate;
    }

    public String getLocale() {
        return locale;
    }

    public void setLocale(String locale) {
        if (locale != null && locale.equals("default")) {
            locale = null;
        }
        this.locale = locale;
    }
}