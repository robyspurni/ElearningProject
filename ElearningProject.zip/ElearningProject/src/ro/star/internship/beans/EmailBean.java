package ro.star.internship.beans;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;

@RequestScoped
@ManagedBean(name=EmailBean.BEAN_NAME)
public class EmailBean {
	public static final String BEAN_NAME = "emailBean";
    public String getBeanName() { return BEAN_NAME; }

	private String email;
	private String subiect;
	private String text;

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	
	public void send(){
		System.out.println("Catre: "+getEmail());
		System.out.println("Subiect: "+getSubiect());
		System.out.println("Text: "+getText());
	}

	public String getSubiect() {
		return subiect;
	}

	public void setSubiect(String subiect) {
		this.subiect = subiect;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}
}
