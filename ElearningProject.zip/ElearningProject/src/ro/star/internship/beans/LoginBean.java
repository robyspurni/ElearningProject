package ro.star.internship.beans;

import javax.annotation.PostConstruct;

//import org.apache.log4j.Logger;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import ro.star.elearning.entities.User;



@SessionScoped
@ManagedBean(name="loginBean")

public class LoginBean {
    private static Logger log = Logger.getLogger(LoginBean.class);
    private static final String REDIRECT_TO_HOME = "/dashboard.xhtml?faces-redirect=true";
    
	private String userName;
	private String password;
	private String password2;
	private String FirstName;
	private String LastName;
	private String email;
	
	
    private boolean selected = true;
    
    public boolean isSelected() {
        return selected;
    }

    public void setSelected(boolean selected) {
        this.selected = selected;
    }
    
    public String getBoxValueDescription() {
        if(selected)
            return "selected";
        else
            return "unselected";
    }
	
	
	@PostConstruct
	public void init() {
		log.info("Running post constructor");
	}
	
	public String getUserName() {
		return userName;
	}
	
	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getFirstName() {
		return FirstName;
	}

	public void setFirstName(String firstName) {
		FirstName = firstName;
	}

	public String getLastName() {
		return LastName;
	}

	public void setLastName(String lastName) {
		LastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	public String userMenu(){
		return User.userName;
	}
	
	public String login() {
		//System.out.println("UserName: " + userName + " " + "Password: " + password);
		if((userName.equals(User.userName)) && (password.equals(User.password))){
		log.info("UserName: " + userName);
		log.info("Password: " + password);
		 return REDIRECT_TO_HOME;}
		else{
			log.info("UserName: " + userName);
			log.info("Password: " + password);
			log.info("Username or Password incorrect");
			log.info("UserName: " + User.userName);
			log.info("Password: " + User.password);
			return "Username or Password incorrect";
		}
		
	}
	
	public boolean register() throws Exception{
		System.out.println("First name: "+getFirstName());
		System.out.println("Last name: "+getLastName());
		System.out.println("Email: "+getEmail());
		System.out.println("Password: "+getPassword2());
		HttpServletResponse response=(HttpServletResponse) FacesContext.getCurrentInstance().getExternalContext().getResponse();
		response.sendRedirect("login.xhtml");
		return true;
	}

	public String getPassword2() {
		return password2;
	}

	public void setPassword2(String password2) {
		this.password2 = password2;
	}

	public void open(){
		
	}
	
	
    }



