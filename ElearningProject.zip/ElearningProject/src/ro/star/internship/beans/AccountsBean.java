package ro.star.internship.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.CustomScoped;
import javax.faces.bean.ManagedBean;
import javax.faces.model.SelectItem;

import ro.star.elearning.entities.Account;

@ManagedBean(name= AccountsBean.BEAN_NAME)
@CustomScoped(value = "#{window}")
public class AccountsBean implements Serializable {
    public static final String BEAN_NAME = "accountsBean";
    public String getBeanName() { return BEAN_NAME; }
    
  
    private List<Account> accounts;
    private int rows = 5;
    private int startPage = 1;
    private boolean fastControls = false;
    

	
    public AccountsBean() {
       accounts = new ArrayList<Account>(Account.getDefaultData());
    }

    
    public List<Account> getAccounts() { return accounts; }
    public void setAccounts(List<Account> accounts) { this.accounts = accounts; }
    
    public int getRows() { return rows; }
    public void setRows(int rows) {
        this.rows = rows;    
        setStartPage(getStartPage());
    }
    

    public int getStartPage() { return startPage; }
    public void setStartPage(int startPage) {
        this.startPage = startPage;
        int maxPages = getStartPageMaximum();
        if( this.startPage < 1 ){
            this.startPage = 1;
        } else if( startPage > maxPages ){
            this.startPage = maxPages;
        }
    }
    
    public int getStartPageMaximum() {
        return rows == 0 ? 1 : (int)Math.ceil(accounts.size()/(double)rows);
    }
    
    
    public boolean getFastControls() { return fastControls; }
    public void setFastControls(boolean fastControls) { this.fastControls = fastControls; }
}